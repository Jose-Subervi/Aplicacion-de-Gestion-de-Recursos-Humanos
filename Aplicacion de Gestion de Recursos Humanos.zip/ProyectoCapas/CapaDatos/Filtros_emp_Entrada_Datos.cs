﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
    public class Filtros_emp_Entrada_Datos
    {
        ProyectEntities db = new ProyectEntities();

        public void FiltroEmpleadosE(Filtros_Entradas emp)
        {
            var amontonar = from em in db.Empleados
                            where em.Fecha_Ingreso == emp.Fecha_Ingreso
                            select em;

            var f = amontonar.FirstOrDefault(x => x.Fecha_Ingreso == emp.Fecha_Ingreso);


            emp.Nombre = f.Nombre;
            //nomi.ID_Nomina = f.ID_Nomina;
            emp.Salario = f.Salario;
            emp.Telefono = f.Telefono;
            emp.Estatus = f.Estatus;
            emp.Fecha_Ingreso = f.Fecha_Ingreso;
            emp.Codigo_Empleado = f.Codigo_Empleado;
            emp.Departamento = f.Departamento;
            emp.Apellido = f.Apellido;
            emp.Cargo = f.Cargo;

        }


        public List<Filtros_Entradas> ListarFiltrosEmpleadosE()
        {
            return db.Filtros_Entradas.ToList();
        }

        public void Guardar(Filtros_Entradas emp)
        {
            db.Filtros_Entradas.Add(emp);
            db.SaveChanges();
        }
    }
}
