﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
    public class Filtros_Permisos_Datos
    {
        ProyectEntities db = new ProyectEntities();

        public void FiltroPermiso(Filtro_Permisos emp)
        {
            var amontonar = from em in db.Permisos
                            where em.Empleado == emp.Empleado
                            select em;

            var f = amontonar.FirstOrDefault(x => x.Empleado == emp.Empleado);


            emp.Empleado = f.Empleado;
            //nomi.ID_Nomina = f.ID_Nomina;
            emp.Desde = f.Desde;
            emp.Hasta = f.Hasta;
            emp.Comentarios = f.Comentarios;

        }


        public List<Filtro_Permisos> ListarFiltrosPermisos()
        {
            return db.Filtro_Permisos.ToList();
        }

        public void Guardar(Filtro_Permisos emp)
        {
            db.Filtro_Permisos.Add(emp);
            db.SaveChanges();
        }
    }
}
