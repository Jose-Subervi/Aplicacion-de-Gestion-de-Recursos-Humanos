﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
    public class Nomina_Datos
    {
        ProyectEntities db = new ProyectEntities();

        public void InsertarNomina(Nominas nm)
        {
            db.Nominas.Add(nm);
            db.SaveChanges();
        }

        public List<Nominas> ListarNomina()
        {
            return db.Nominas.ToList();
        }

        public void SumarSalario(Nominas nm)
        {

            var amontonar = from emp in db.Empleados
                            where emp.Estatus.Length == 6
                            select emp;

                var totalsalary = amontonar.Sum(emp => emp.Salario);
                nm.Monto_Total = totalsalary;


        }

        public void ActualizarNominas(Nominas nm)
        {
            var registro = db.Nominas.First(z => z.ID_Nomina == nm.ID_Nomina);
            registro.Año = nm.Año;
            registro.Mes = nm.Mes;
            registro.Monto_Total = nm.Monto_Total;
            db.SaveChanges();
        }

        public void BorrarNominas(Nominas nm)
        {
            var registro = db.Nominas.First(z => z.ID_Nomina == nm.ID_Nomina);
            db.Nominas.Remove(registro);
            db.SaveChanges();
        }
    }
}
