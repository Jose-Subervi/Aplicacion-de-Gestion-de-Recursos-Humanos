﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
    public class Departamentos_Datos
    {
        ProyectEntities db = new ProyectEntities();

        public void InsertarDepartamento(Departamentos dep)
        {
            db.Departamentos.Add(dep);
            db.SaveChanges();
        }

        public List<Departamentos> ListarDepartamentos()
        {
            return db.Departamentos.ToList();
        }

        public void ActualizarDepartamentos(Departamentos dep)
        {
            var registro = db.Departamentos.First(z => z.ID_Departamento == dep.ID_Departamento);
            registro.Codigo_Departamento = dep.Codigo_Departamento;
            registro.Nombre = dep.Nombre;
            db.SaveChanges();
        }

        public void BorrarDepartamento(Departamentos dep)
        {
            var registro = db.Departamentos.First(z => z.ID_Departamento == dep.ID_Departamento);
            db.Departamentos.Remove(registro);
            db.SaveChanges();
        }
    }
}
