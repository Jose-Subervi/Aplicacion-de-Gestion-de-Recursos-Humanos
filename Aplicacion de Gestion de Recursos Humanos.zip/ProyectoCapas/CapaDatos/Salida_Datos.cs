﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
    public class Salida_Datos
    {
        ProyectEntities db = new ProyectEntities();

        public void InsertarSalidas(Salida_Empleados se)
        {
            db.Salida_Empleados.Add(se);
            db.SaveChanges();
        }
        public List<Salida_Empleados> ListarSalidaEmpleados()
        {
            return db.Salida_Empleados.ToList();
        }

        public void AgregarEmp(Salida_Empleados se)
        {
            //int y = 6;
            //var e = from emp in db.Empleados
            //        select emp.Estatus.Where('Activo');
            //var ee = e.Any(x => x.Length <= 6);

            Empleados mp = new Empleados();

            //var amontonar = from emp in db.Empleados
            //                where emp.ID == se.ID_Salida
            //                select emp;

            //var totalsalary = amontonar.Sum(emp => emp.Salario);
            //nm.Monto_Total = totalsalary;

            //var amontonar = from emp in db.Empleados 
            //                join sp in db.Salida_Empleados on emp.ID equals sp.ID_Salida 
            //                select emp.Codigo_Empleado;

            var amontonar = from emp in db.Empleados
                            select emp;

            //var mm = amontonar.Where(x => se.ID_Salida == x.ID).Select(x => x.Codigo_Empleado);

            var f = amontonar.FirstOrDefault(x => x.ID == se.ID_Salida);

            se.Empleado = f.Codigo_Empleado;

            var amontonar1 = from emp1 in db.Empleados
                             select emp1;

            var ff = amontonar1.FirstOrDefault(x => x.ID == se.ID_Salida);

            f.Estatus = "Inactivo";


            //var reg = amontonar.Select(emp => se.Empleado);

            //var m = from ma in db.Empleados
            //        select ma.Codigo_Empleado;



            //var regi = db.Salida_Empleados.First(x => x.ID_Salida == mp.ID);
            //regi.Empleado = mp.Codigo_Empleado;

            //var g = db.Salida_Empleados.First(x => x.ID_Salida == mp.ID);
            //g.Empleado = mp.Codigo_Empleado;

            //var ww = amontonar.Where(x => x.)


        }

        public void ActualizarSalidas(Salida_Empleados se)
        {
            var registro = db.Salida_Empleados.First(z => z.ID_Salida == se.ID_Salida);
            registro.Tipo_Salida = se.Tipo_Salida;
            registro.Motivo= se.Motivo;
            registro.Fecha_Salida = se.Fecha_Salida;
            db.SaveChanges();
        }

        public void BorrarEmpleados(Salida_Empleados se)
        {
            var registro = db.Salida_Empleados.First(z => z.ID_Salida == se.ID_Salida);
            db.Salida_Empleados.Remove(registro);
            db.SaveChanges();
        }
    }
}
