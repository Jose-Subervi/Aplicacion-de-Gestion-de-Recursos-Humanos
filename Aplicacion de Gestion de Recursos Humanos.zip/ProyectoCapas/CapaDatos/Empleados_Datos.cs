﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
    public class Empleados_Datos
    {
        ProyectEntities db = new ProyectEntities();

        public void InsertarEmpleados(Empleados emple)
        {
            db.Empleados.Add(emple);
            db.SaveChanges();
        }

        public List<Empleados> ListarEmpleados()
        {
            return db.Empleados.ToList();
        }

        public void ActualizarEmpleados(Empleados emp)
        {
            var registro = db.Empleados.First(z => z.ID == emp.ID);
            registro.Codigo_Empleado = emp.Codigo_Empleado;
            registro.Nombre = emp.Nombre;
            registro.Apellido = emp.Apellido;
            registro.Telefono = emp.Telefono;
            registro.Departamento = emp.Departamento;
            registro.Cargo = emp.Cargo;
            registro.Fecha_Ingreso = emp.Fecha_Ingreso;
            registro.Salario = emp.Salario;
            registro.Estatus = emp.Estatus;
            db.SaveChanges();
        }

        public void BorrarEmpleados(Empleados emp)
        {
            var registro = db.Empleados.First(z => z.ID == emp.ID);
            db.Empleados.Remove(registro);
            db.SaveChanges();
        }
        
    }
}
