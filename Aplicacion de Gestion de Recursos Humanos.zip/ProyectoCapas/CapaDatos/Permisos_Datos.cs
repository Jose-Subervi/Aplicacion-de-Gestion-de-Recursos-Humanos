﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
    public class Permisos_Datos
    {
        ProyectEntities db = new ProyectEntities();

        public void InsertarPermisos(Permisos pm)
        {
            db.Permisos.Add(pm);
            db.SaveChanges();
        }

        public List<Permisos> ListarPermisos()
        {
            return db.Permisos.ToList();
        }

        public void AgregarEmp(Permisos pm)
        {

            var amontonar = from emp in db.Empleados
                            select emp;

            var f = amontonar.FirstOrDefault(x => x.ID == pm.ID_Permisos);

            pm.Empleado = f.Codigo_Empleado;


        }

        public void ActualizarPermisos(Permisos pm)
        {
            var registro = db.Permisos.First(z => z.ID_Permisos == pm.ID_Permisos);
            registro.Empleado = pm.Empleado;
            registro.Hasta = pm.Hasta;
            registro.Desde = pm.Desde;
            registro.Comentarios = pm.Comentarios;
            db.SaveChanges();
        }

        public void BorrarPermisos(Permisos pm)
        {
            var registro = db.Permisos.First(z => z.ID_Permisos == pm.ID_Permisos);
            db.Permisos.Remove(registro);
            db.SaveChanges();
        }
    }
}
