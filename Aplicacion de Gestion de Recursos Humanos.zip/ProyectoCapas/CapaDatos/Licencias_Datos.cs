﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
    public class Licencias_Datos
    {
        ProyectEntities db = new ProyectEntities();

        public void InsertarLicencias(Licencias lc)
        {
            db.Licencias.Add(lc);
            db.SaveChanges();
        }

        public List<Licencias> ListarLicencias()
        {
            return db.Licencias.ToList();
        }

        public void AgregarEmp(Licencias lc)
        {

            var amontonar = from emp in db.Empleados
                            select emp;

            var f = amontonar.FirstOrDefault(x => x.ID == lc.ID_Licencias);

            lc.Empleado = f.Codigo_Empleado;


        }

        public void ActualizarLicencias(Licencias lc)
        {
            var registro = db.Licencias.First(z => z.ID_Licencias == lc.ID_Licencias);
            registro.Empleado = lc.Empleado;
            registro.Desde = lc.Desde;
            registro.Comentarios = lc.Comentarios;
            registro.Hasta = lc.Hasta;
            registro.Motivo = lc.Motivo;
            db.SaveChanges();
        }

        public void BorrarLicencias(Licencias lc)
        {
            var registro = db.Licencias.First(z => z.ID_Licencias == lc.ID_Licencias);
            db.Licencias.Remove(registro);
            db.SaveChanges();
        }
    }
}
