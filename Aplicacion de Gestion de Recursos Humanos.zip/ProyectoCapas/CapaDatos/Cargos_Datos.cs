﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
    public class Cargos_Datos
    {
        ProyectEntities db = new ProyectEntities();

        public void InsertarCargos(Cargos cg)
        {
            db.Cargos.Add(cg);
            db.SaveChanges();
        }

        public List<Cargos> ListarCargos()
        {
            return db.Cargos.ToList();
        }

        public void ActualizarCargos(Cargos cg)
        {
            var registro = db.Cargos.First(z => z.ID_Cargo == cg.ID_Cargo);
            registro.Cargo = cg.Cargo;
            db.SaveChanges();
        }

        public void BorrarCargos(Cargos cg)
        {
            var registro = db.Cargos.First(z => z.ID_Cargo == cg.ID_Cargo);
            db.Cargos.Remove(registro);
            db.SaveChanges();
        }
    }
}
