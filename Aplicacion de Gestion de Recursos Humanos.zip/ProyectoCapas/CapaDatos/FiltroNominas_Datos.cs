﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
    public class FiltroNominas_Datos
    {
        ProyectEntities db = new ProyectEntities();

        public void FiltroNomina(Filtros_Nominas nomi)
        {
            var amontonar = from nm in db.Nominas
                            where nm.Año == nomi.Año
                            select nm;


            var f = amontonar.FirstOrDefault(x => x.Año == nomi.Año);        


            nomi.Año = f.Año;
            nomi.Mes = f.Mes;
            nomi.Monto_Total = f.Monto_Total;



        }
        public List<Filtros_Nominas> ListarFiltrosNominas()
        {
            return db.Filtros_Nominas.ToList();
        }

        public void Guardar(Filtros_Nominas nomi)
        {
            db.Filtros_Nominas.Add(nomi);
            db.SaveChanges();
        }

        public void FiltrarMes(Filtros_Nominas nomi) 
        {
            var amontonar1 = from nm1 in db.Nominas
                             where nm1.Mes == nomi.Mes
                             select nm1;

            var f = amontonar1.FirstOrDefault(x => x.Mes == nomi.Mes);


            nomi.Año = f.Año;
            nomi.Mes = f.Mes;
            nomi.Monto_Total = f.Monto_Total;
        }
    }
}
