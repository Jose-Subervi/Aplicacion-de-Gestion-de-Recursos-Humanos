﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
    public class Vacacione_Datos
    {
        ProyectEntities db = new ProyectEntities();

        public void InsertarVacaciones(Vacaciones vc)
        {
            db.Vacaciones.Add(vc);
            db.SaveChanges();
        }

        public List<Vacaciones> ListarVacaciones()
        {
            return db.Vacaciones.ToList();
        }

        public void AgregarEmp(Vacaciones vc)
        {

            var amontonar = from emp in db.Empleados
                            select emp;

            var f = amontonar.FirstOrDefault(x => x.ID == vc.ID_Vacaciones);

            vc.Empleado = f.Codigo_Empleado;


        }

        public void ActualizarVacaciones(Vacaciones vc)
        {
            var registro = db.Vacaciones.First(z => z.ID_Vacaciones == vc.ID_Vacaciones);
            registro.Empleado = vc.Empleado;
            registro.Año = vc.Año;
            registro.Desde = vc.Desde;
            registro.Comentarios = vc.Comentarios;
            registro.Hasta = vc.Hasta;
            db.SaveChanges();
        }

        public void BorrarVacaciones(Vacaciones vc)
        {
            var registro = db.Vacaciones.First(z => z.ID_Vacaciones == vc.ID_Vacaciones);
            db.Vacaciones.Remove(registro);
            db.SaveChanges();
        }
    }
}
