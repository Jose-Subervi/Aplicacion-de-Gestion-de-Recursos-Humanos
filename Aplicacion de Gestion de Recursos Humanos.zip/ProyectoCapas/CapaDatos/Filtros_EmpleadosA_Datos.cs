﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
    public class Filtros_EmpleadosA_Datos
    {
        ProyectEntities db = new ProyectEntities();

        public void Filtro_EmpleadosAN(Filtros_Empleados emp)
        {
            var amontonar = from em in db.Empleados
                            where em.Nombre == emp.Nombre
                            select em;

            var f = amontonar.FirstOrDefault(x => x.Nombre == emp.Nombre);


            emp.Nombre = f.Nombre;
            //nomi.ID_Nomina = f.ID_Nomina;
            emp.Salario = f.Salario;
            emp.Telefono = f.Telefono;
            emp.Estatus = f.Estatus;
            emp.Fecha_Ingreso = f.Fecha_Ingreso;
            emp.Codigo_Empleado = f.Codigo_Empleado;
            emp.Departamento = f.Departamento;
            emp.Apellido = f.Apellido;
            emp.Cargo = f.Cargo;

        }

        public void Filtro_EmpleadosAD(Filtros_Empleados emp)
        {
            var amontonar = from em in db.Empleados
                            where em.Departamento == emp.Departamento
                            select em;

            var f = amontonar.FirstOrDefault(x => x.Departamento == emp.Departamento);


            emp.Nombre = f.Nombre;
            //nomi.ID_Nomina = f.ID_Nomina;
            emp.Salario = f.Salario;
            emp.Telefono = f.Telefono;
            emp.Estatus = f.Estatus;
            emp.Fecha_Ingreso = f.Fecha_Ingreso;
            emp.Codigo_Empleado = f.Codigo_Empleado;
            emp.Departamento = f.Departamento;
            emp.Apellido = f.Apellido;
            emp.Cargo = f.Cargo;

        }


        public List<Filtros_Empleados> ListarFiltrosEmpleadosE()
        {
            return db.Filtros_Empleados.ToList();
        }

        public void Guardar(Filtros_Empleados emp)
        {
            db.Filtros_Empleados.Add(emp);
            db.SaveChanges();
        }
    }
}
