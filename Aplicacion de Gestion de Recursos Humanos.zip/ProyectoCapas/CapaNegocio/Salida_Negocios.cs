﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using CapaDatos;

namespace CapaNegocio
{
    public class Salida_Negocios
    {
        Salida_Datos ejecutor = new Salida_Datos();

        public void GuardarSalida(Salida_Empleados elemento)
        {
            ejecutor.InsertarSalidas(elemento);
        }

        public List<Salida_Empleados> MostrarDatos()
        {
            return ejecutor.ListarSalidaEmpleados();
        }

        public void AgregarEmp(Salida_Empleados se)
        {
            ejecutor.AgregarEmp(se);
        }

        public void ActualizarSalidas(Salida_Empleados se)
        {
            ejecutor.ActualizarSalidas(se);
        }

        public void BorrarSalidas(Salida_Empleados se)
        {
            ejecutor.BorrarEmpleados(se);
        }
    }
}
