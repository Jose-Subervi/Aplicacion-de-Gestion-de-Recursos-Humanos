﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using CapaEntidad;

namespace CapaNegocio
{
    public class Licencias_Negocios
    {
        Licencias_Datos ejecutor = new Licencias_Datos();

        public void GuardarLicencia(Licencias elemento)
        {
            ejecutor.InsertarLicencias(elemento);
        }

        public List<Licencias> MostrarDatos()
        {
            return ejecutor.ListarLicencias();
        }

        public void AgregarEmp(Licencias lc)
        {
            ejecutor.AgregarEmp(lc);
        }

        public void ActualizarLicencia(Licencias lc)
        {
            ejecutor.ActualizarLicencias(lc);
        }

        public void BorrarLicencia(Licencias lc)
        {
            ejecutor.BorrarLicencias(lc);
        }
    }
}
