﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using CapaDatos;

namespace CapaNegocio
{
    public class Vacacione_Negocios
    {
        Vacacione_Datos ejecutor = new Vacacione_Datos();

        public void GuardarVacaciones(Vacaciones elemento)
        {
            ejecutor.InsertarVacaciones(elemento);
        }

        public List<Vacaciones> MostrarDatos()
        {
            return ejecutor.ListarVacaciones();
        }

        public void AgregarEmp(Vacaciones vc)
        {
            ejecutor.AgregarEmp(vc);
        }

        public void ActualizarVacaciones(Vacaciones vc)
        {
            ejecutor.ActualizarVacaciones(vc);
        }

        public void BorrarVacaciones(Vacaciones vc)
        {
            ejecutor.BorrarVacaciones(vc);
        }
    }
}
