﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using CapaEntidad;

namespace CapaNegocio
{
    public class Cargos_Negocios
    {
        Cargos_Datos ejecutor = new Cargos_Datos();

        public void GuardarCargos(Cargos elemento)
        {
            ejecutor.InsertarCargos(elemento);
        }

        public List<Cargos> MostrarDatos()
        {
            return ejecutor.ListarCargos();
        }
        public void ActualizaCargos(Cargos cg)
        {
            ejecutor.ActualizarCargos(cg);
        }

        public void BorrarCargos(Cargos cg)
        {
            ejecutor.BorrarCargos(cg);
        }
    }
}
