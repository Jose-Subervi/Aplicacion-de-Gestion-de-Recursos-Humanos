﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using CapaEntidad;

namespace CapaNegocio
{
    public class Departamentos_Negocios
    {
        Departamentos_Datos ejecutor = new Departamentos_Datos();

        public void GuardarDepartamento(Departamentos elemento)
        {
            ejecutor.InsertarDepartamento(elemento);
        }

        public List<Departamentos> MostrarDatos()
        {
            return ejecutor.ListarDepartamentos();
        }
        public void ActualizarDepartamento(Departamentos dep)
        {
            ejecutor.ActualizarDepartamentos(dep);
        }

        public void BorrarDepartamento(Departamentos dep)
        {
            ejecutor.BorrarDepartamento(dep);
        }
    }
}
