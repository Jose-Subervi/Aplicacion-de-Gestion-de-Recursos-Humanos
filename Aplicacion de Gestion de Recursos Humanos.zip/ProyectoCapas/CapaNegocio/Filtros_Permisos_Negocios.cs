﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using CapaDatos;

namespace CapaNegocio
{
    public class Filtros_Permisos_Negocios
    {
        Filtros_Permisos_Datos ejecutor = new Filtros_Permisos_Datos();

        public void Filtro_Permisos(Filtro_Permisos emp)
        {
            ejecutor.FiltroPermiso(emp);
        }

        public List<Filtro_Permisos> ListarFiltrosPermisos()
        {
            return ejecutor.ListarFiltrosPermisos();
        }

        public void GuardarPermisos(Filtro_Permisos emp)
        {
            ejecutor.Guardar(emp);
        }
    }
}
