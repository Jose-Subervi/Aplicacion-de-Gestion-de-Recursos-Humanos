﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using CapaDatos;

namespace CapaNegocio
{
    public class Filtros_emp_Salida_Negocio
    {
        Filtros_emp_Salida_Datos ejecutor = new Filtros_emp_Salida_Datos();

        public void Filtro_EmpleadosS(Filtros_Salidas emp)
        {
            ejecutor.FiltroEmpleadosS(emp);
        }

        public List<Filtros_Salidas> ListarFiltrosEmpleados()
        {
            return ejecutor.ListarFiltrosEmpleadosS();
        }

        public void GuardarEmpleadosS(Filtros_Salidas emp)
        {
            ejecutor.Guardar(emp);
        }
    }
}
