﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using CapaDatos;

namespace CapaNegocio
{
    public class Filtros_EmpleadosA_Negocios
    {
        Filtros_EmpleadosA_Datos ejecutor = new Filtros_EmpleadosA_Datos();

        public void Filtro_EmpleadosAN(Filtros_Empleados emp)
        {
            ejecutor.Filtro_EmpleadosAN(emp);
        }

        public void Filtro_EmpleadosAD(Filtros_Empleados emp)
        {
            ejecutor.Filtro_EmpleadosAN(emp);
        }

        public List<Filtros_Empleados> ListarFiltrosEmpleados()
        {
            return ejecutor.ListarFiltrosEmpleadosE();
        }

        public void GuardarEmpleadosA(Filtros_Empleados emp)
        {
            ejecutor.Guardar(emp);
        }
    }
}
