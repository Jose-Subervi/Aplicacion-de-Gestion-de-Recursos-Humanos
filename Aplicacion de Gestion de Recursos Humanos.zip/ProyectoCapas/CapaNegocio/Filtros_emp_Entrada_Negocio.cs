﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using CapaEntidad;

namespace CapaNegocio
{
    public class Filtros_emp_Entrada_Negocio
    {
        Filtros_emp_Entrada_Datos ejecutor = new Filtros_emp_Entrada_Datos();

        public void Filtro_EmpleadosE(Filtros_Entradas emp)
        {
            ejecutor.FiltroEmpleadosE(emp);
        }

        public List<Filtros_Entradas> ListarFiltrosEmpleados()
        {
            return ejecutor.ListarFiltrosEmpleadosE();
        }

        public void GuardarEmpleadosE(Filtros_Entradas emp)
        {
            ejecutor.Guardar(emp);
        }
    }
}
