﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using CapaEntidad;

namespace CapaNegocio
{
    public class FiltroNominas_Negocios
    {
        FiltroNominas_Datos ejecutor = new FiltroNominas_Datos();

        public void FiltroNomina(Filtros_Nominas nomi)
        {
            ejecutor.FiltroNomina(nomi);
        }

        public List<Filtros_Nominas> MostrarDatos()
        {
            return ejecutor.ListarFiltrosNominas();
        }

        public void Guardar(Filtros_Nominas nomi)
        {
            ejecutor.Guardar(nomi);
        }

        public void FiltroNominaMes(Filtros_Nominas nomi)
        {
            ejecutor.FiltrarMes(nomi);
        }
    }
}
