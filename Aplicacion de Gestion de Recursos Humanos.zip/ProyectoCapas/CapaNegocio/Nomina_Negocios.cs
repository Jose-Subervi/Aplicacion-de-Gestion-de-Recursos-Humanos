﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using CapaDatos;

namespace CapaNegocio
{
    public class Nomina_Negocios
    {
        Nomina_Datos ejecutor = new Nomina_Datos();

        public void GuardarNomina(Nominas elemento)
        {
            ejecutor.InsertarNomina(elemento);
        }

        public List<Nominas> MostrarDatos()
        {
            return ejecutor.ListarNomina();
        }

        public void SumasSalario(Nominas nm)
        {
            ejecutor.SumarSalario(nm);
        }

        public void ActualizarNomina(Nominas nm)
        {
            ejecutor.ActualizarNominas(nm);
        }

        public void BorrarNomina(Nominas nm)
        {
            ejecutor.BorrarNominas(nm);
        }
    }
}
