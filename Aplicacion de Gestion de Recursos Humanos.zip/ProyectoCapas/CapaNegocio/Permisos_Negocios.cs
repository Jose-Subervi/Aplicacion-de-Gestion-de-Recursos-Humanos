﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using CapaDatos;

namespace CapaNegocio
{
    public class Permisos_Negocios
    {
        Permisos_Datos ejecutor = new Permisos_Datos();

        public void GuardarPermisos(Permisos elemento)
        {
            ejecutor.InsertarPermisos(elemento);
        }

        public List<Permisos> MostrarDatos()
        {
            return ejecutor.ListarPermisos();
        }

        public void AgregarEmp(Permisos pm)
        {
            ejecutor.AgregarEmp(pm);
        }

        public void ActualizarPermisos(Permisos pm)
        {
            ejecutor.ActualizarPermisos(pm);
        }

        public void BorrarPermisos(Permisos pm)
        {
            ejecutor.BorrarPermisos(pm);
        }
    }
}
