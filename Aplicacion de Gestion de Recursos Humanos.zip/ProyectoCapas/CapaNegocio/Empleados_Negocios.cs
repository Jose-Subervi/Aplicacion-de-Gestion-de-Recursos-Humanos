﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using CapaEntidad;

namespace CapaNegocio
{
    public class Empleados_Negocios
    {
        Empleados_Datos ejecutor = new Empleados_Datos();

        public void GuardarEmpleados(Empleados elemento)
        {
            ejecutor.InsertarEmpleados(elemento);
        }

        public List<Empleados> MostrarEmpleados()
        {
            return ejecutor.ListarEmpleados();
        }
        public void ActualizarEmpleados(Empleados emp)
        {
            ejecutor.ActualizarEmpleados(emp);
        }

        public void BorrarEmpleados(Empleados emp)
        {
            ejecutor.BorrarEmpleados(emp);
        }
    }
}
