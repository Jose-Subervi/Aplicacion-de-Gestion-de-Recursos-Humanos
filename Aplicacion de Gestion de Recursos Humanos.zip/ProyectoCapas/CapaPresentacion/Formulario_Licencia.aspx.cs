﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocio;
using CapaEntidad;

namespace CapaPresentacion
{
    public partial class Formulario_Licencia : System.Web.UI.Page
    {
        Licencias lc = new Licencias();
        Licencias_Negocios ejecutor = new Licencias_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonGuardar_Click(object sender, EventArgs e)
        {
            lc.ID_Licencias = int.Parse(TextBoxID.Text);
            lc.Comentarios = TextBoxComentarios.Text;
            lc.Motivo = TextBoxMotivo.Text;
            lc.Desde = TextBoxDesde.Text;
            lc.Hasta = TextBoxHasta.Text;

            ejecutor.AgregarEmp(lc);
            ejecutor.GuardarLicencia(lc);

            TextBoxHasta.Text = " ";
            TextBoxDesde.Text = " ";
            TextBoxMotivo.Text = " ";
            TextBoxComentarios.Text = " ";
            TextBoxID.Text = " ";
        }

        protected void ButtonActualizar_Click(object sender, EventArgs e)
        {
            lc.ID_Licencias = int.Parse(TextBoxID.Text);
            lc.Comentarios = TextBoxComentarios.Text;
            lc.Motivo = TextBoxMotivo.Text;
            lc.Desde = TextBoxDesde.Text;
            lc.Hasta = TextBoxHasta.Text;

            ejecutor.ActualizarLicencia(lc);

            TextBoxHasta.Text = " ";
            TextBoxDesde.Text = " ";
            TextBoxMotivo.Text = " ";
            TextBoxComentarios.Text = " ";
            TextBoxID.Text = " ";
        }

        protected void ButtonBorrar_Click(object sender, EventArgs e)
        {
            lc.ID_Licencias = int.Parse(TextBoxID.Text);
            lc.Comentarios = TextBoxComentarios.Text;
            lc.Motivo = TextBoxMotivo.Text;
            lc.Desde = TextBoxDesde.Text;
            lc.Hasta = TextBoxHasta.Text;

            ejecutor.BorrarLicencia(lc);

            TextBoxHasta.Text = " ";
            TextBoxDesde.Text = " ";
            TextBoxMotivo.Text = " ";
            TextBoxComentarios.Text = " ";
            TextBoxID.Text = " ";
        }
    }
}