﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocio;


namespace CapaPresentacion
{
    public partial class ListadoEmpleados : System.Web.UI.Page
    {
        Empleados_Negocios ejecutor = new Empleados_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {
            RepeaterEmpleados.DataSource = ejecutor.MostrarEmpleados();
            RepeaterEmpleados.DataBind();
        }
    }
}