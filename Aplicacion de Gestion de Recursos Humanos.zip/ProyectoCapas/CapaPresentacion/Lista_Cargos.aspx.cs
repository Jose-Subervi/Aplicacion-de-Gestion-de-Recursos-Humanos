﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class Lista_Cargos : System.Web.UI.Page
    {
        Cargos_Negocios ejecutor = new Cargos_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {
            RepeaterCargos.DataSource = ejecutor.MostrarDatos();
            RepeaterCargos.DataBind();
        }
    }
}