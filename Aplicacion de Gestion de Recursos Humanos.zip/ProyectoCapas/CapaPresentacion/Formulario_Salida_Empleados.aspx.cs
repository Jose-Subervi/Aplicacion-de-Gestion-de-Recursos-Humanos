﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocio;
using CapaEntidad;


namespace CapaPresentacion
{
    public partial class Formulario_Salida_Empleados : System.Web.UI.Page
    {
        Salida_Empleados se = new Salida_Empleados();
        Salida_Negocios ejecutor = new Salida_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonGuardar_Click(object sender, EventArgs e)
        {
            se.ID_Salida = int.Parse(TextBoxID.Text);
            se.Tipo_Salida = DropDownList1.SelectedValue;
            se.Motivo = TextBoxMotivo.Text;
            se.Fecha_Salida = TextBoxFecha_Salida.Text;

            ejecutor.AgregarEmp(se);
            ejecutor.GuardarSalida(se);

            TextBoxMotivo.Text = " ";
            TextBoxFecha_Salida.Text = " ";
        }

        protected void ButtonActualizar_Click(object sender, EventArgs e)
        {
            se.ID_Salida = int.Parse(TextBoxID.Text);
            se.Motivo = TextBoxMotivo.Text;
            se.Fecha_Salida = TextBoxFecha_Salida.Text;


            ejecutor.ActualizarSalidas(se);

            TextBoxID.Text = " ";
            TextBoxFecha_Salida.Text = " ";
            TextBoxMotivo.Text = " ";
        }

        protected void ButtonBorrar_Click(object sender, EventArgs e)
        {
            se.ID_Salida = int.Parse(TextBoxID.Text);
            se.Motivo = TextBoxMotivo.Text;
            se.Fecha_Salida = TextBoxFecha_Salida.Text;

            ejecutor.BorrarSalidas(se);

            TextBoxID.Text = " ";
            TextBoxMotivo.Text = " ";
            TextBoxFecha_Salida.Text = " ";
        }
    }
}