﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaEntidad;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class Filtros_emp_Entrada : System.Web.UI.Page
    {
        Filtros_Entradas emp = new Filtros_Entradas();
        Filtros_emp_Entrada_Negocio ejecutor = new Filtros_emp_Entrada_Negocio();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonGuardar_Click(object sender, EventArgs e)
        {
            emp.Fecha_Ingreso = TextBoxFiltroFechaI.Text;

            ejecutor.Filtro_EmpleadosE(emp);
            ejecutor.GuardarEmpleadosE(emp);

            RepeaterFiltroEmpleadoEntrada.DataSource = ejecutor.ListarFiltrosEmpleados();
            RepeaterFiltroEmpleadoEntrada.DataBind();
        }
    }
}