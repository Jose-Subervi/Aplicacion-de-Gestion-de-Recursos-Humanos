﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocio;
using CapaEntidad;

namespace CapaPresentacion
{
    public partial class Formulario_Cargos : System.Web.UI.Page
    {
        Cargos cg = new Cargos();
        Cargos_Negocios ejecutor = new Cargos_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonGuardar_Click(object sender, EventArgs e)
        {
            cg.Cargo = TextBoxCargos.Text;


            ejecutor.GuardarCargos(cg);

            TextBoxCargos.Text = " ";
        }

        protected void ButtonActualizar_Click(object sender, EventArgs e)
        {
            cg.ID_Cargo = int.Parse(TextBoxID.Text);
            cg.Cargo = TextBoxCargos.Text;


            ejecutor.ActualizaCargos(cg);

            TextBoxID.Text = " ";
            TextBoxCargos.Text = " ";
        }

        protected void ButtonBorrar_Click(object sender, EventArgs e)
        {
            cg.ID_Cargo = int.Parse(TextBoxID.Text);
            cg.Cargo = TextBoxCargos.Text;
  

            ejecutor.BorrarCargos(cg);

            TextBoxID.Text = " ";
            TextBoxCargos.Text = " ";
        }
    }
}