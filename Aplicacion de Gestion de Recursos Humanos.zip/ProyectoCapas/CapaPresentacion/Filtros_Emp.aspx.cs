﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaEntidad;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class Filtros_Emp : System.Web.UI.Page
    {
        Filtros_Empleados emp = new Filtros_Empleados();
        Filtros_EmpleadosA_Negocios ejecutor = new Filtros_EmpleadosA_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonGuardar_Click(object sender, EventArgs e)
        {
            emp.Nombre = TextBoxFiltroNombre.Text;

            ejecutor.Filtro_EmpleadosAN(emp);
            ejecutor.GuardarEmpleadosA(emp);

            RepeaterFiltroEmpleado.DataSource = ejecutor.ListarFiltrosEmpleados();
            RepeaterFiltroEmpleado.DataBind();
        }

        protected void ButtonGuardar1_Click(object sender, EventArgs e)
        {
            emp.Departamento = TextBoxFiltroDepartamento.Text;

            ejecutor.Filtro_EmpleadosAD(emp);
            ejecutor.GuardarEmpleadosA(emp);

            RepeaterFiltroEmpleado.DataSource = ejecutor.ListarFiltrosEmpleados();
            RepeaterFiltroEmpleado.DataBind();
        }
    }
}