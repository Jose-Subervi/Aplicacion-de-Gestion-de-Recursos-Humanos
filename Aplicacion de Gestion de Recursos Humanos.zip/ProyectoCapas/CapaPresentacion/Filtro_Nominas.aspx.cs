﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaEntidad;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class Filtro_Nominas : System.Web.UI.Page
    {
        Filtros_Nominas nomi = new Filtros_Nominas();
        FiltroNominas_Negocios ejecutor = new FiltroNominas_Negocios();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            

        }

        protected void ButtonGuardar_Click(object sender, EventArgs e)
        {
            nomi.Año = TextBoxFiltroNomina.Text;

            ejecutor.FiltroNomina(nomi);
            ejecutor.Guardar(nomi);

            RepeaterFiltroNomina.DataSource = ejecutor.MostrarDatos();
            RepeaterFiltroNomina.DataBind();

        }

        protected void ButtonGuardar1_Click(object sender, EventArgs e)
        {
            nomi.Mes = TextBoxFiltroMes.Text;

            ejecutor.FiltroNominaMes(nomi);
            ejecutor.Guardar(nomi);

            RepeaterFiltroNomina.DataSource = ejecutor.MostrarDatos();
            RepeaterFiltroNomina.DataBind();
        }
    }
}