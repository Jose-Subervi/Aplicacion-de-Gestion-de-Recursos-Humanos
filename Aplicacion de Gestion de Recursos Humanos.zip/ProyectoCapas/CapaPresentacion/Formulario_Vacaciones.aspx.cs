﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaEntidad;
using CapaNegocio;


namespace CapaPresentacion
{
    public partial class Formulario_Vacaciones : System.Web.UI.Page
    {
        Vacaciones vc = new Vacaciones();
        Vacacione_Negocios ejecutor = new Vacacione_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonGuardar_Click(object sender, EventArgs e)
        {
            vc.ID_Vacaciones = int.Parse(TextBoxID.Text);
            vc.Comentarios = TextBoxComentarios.Text;
            vc.Año = TextBoxAño.Text;
            vc.Desde = TextBoxDesde.Text;
            vc.Hasta = TextBoxHasta.Text;

            ejecutor.AgregarEmp(vc);
            ejecutor.GuardarVacaciones(vc);

            TextBoxHasta.Text = " ";
            TextBoxDesde.Text = " ";
            TextBoxAño.Text = " ";
            TextBoxComentarios.Text = " ";
            TextBoxID.Text = " ";
        }

        protected void ButtonActualizar_Click(object sender, EventArgs e)
        {
            vc.ID_Vacaciones = int.Parse(TextBoxID.Text);
            vc.Comentarios = TextBoxComentarios.Text;
            vc.Año = TextBoxAño.Text;
            vc.Desde = TextBoxDesde.Text;
            vc.Hasta = TextBoxHasta.Text;


            ejecutor.ActualizarVacaciones(vc);

            TextBoxHasta.Text = " ";
            TextBoxDesde.Text = " ";
            TextBoxAño.Text = " ";
            TextBoxComentarios.Text = " ";
            TextBoxID.Text = " ";
        }

        protected void ButtonBorrar_Click(object sender, EventArgs e)
        {
            vc.ID_Vacaciones = int.Parse(TextBoxID.Text);
            vc.Comentarios = TextBoxComentarios.Text;
            vc.Año = TextBoxAño.Text;
            vc.Desde = TextBoxDesde.Text;
            vc.Hasta = TextBoxHasta.Text;

            ejecutor.BorrarVacaciones(vc);

            TextBoxHasta.Text = " ";
            TextBoxDesde.Text = " ";
            TextBoxAño.Text = " ";
            TextBoxComentarios.Text = " ";
            TextBoxID.Text = " ";
        }
    }
}