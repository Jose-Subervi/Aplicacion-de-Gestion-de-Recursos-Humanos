﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaEntidad;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class Formulario_Nomina : System.Web.UI.Page
    {
        Nominas nm = new Nominas();
        Nomina_Negocios ejecutor = new Nomina_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonGuardar_Click(object sender, EventArgs e)
        {
            nm.Año = TextBoxAño.Text;
            nm.Mes = TextBoxMes.Text;
            ejecutor.SumasSalario(nm);

            ejecutor.GuardarNomina(nm);

            TextBoxAño.Text = " ";
            TextBoxMes.Text = " ";
        }

        protected void ButtonActualizar_Click(object sender, EventArgs e)
        {
            nm.ID_Nomina = int.Parse(TextBoxID.Text);
            nm.Año = TextBoxAño.Text;
            nm.Mes = TextBoxMes.Text;


            ejecutor.ActualizarNomina(nm);

            TextBoxID.Text = " ";
            TextBoxAño.Text = " ";
            TextBoxMes.Text = " ";
        }

        protected void ButtonBorrar_Click(object sender, EventArgs e)
        {
            nm.ID_Nomina = int.Parse(TextBoxID.Text);
            nm.Año = TextBoxAño.Text;
            nm.Mes = TextBoxMes.Text;

            ejecutor.BorrarNomina(nm);

            TextBoxID.Text = " ";
            TextBoxAño.Text = " ";
            TextBoxMes.Text = " ";

        }
    }
}