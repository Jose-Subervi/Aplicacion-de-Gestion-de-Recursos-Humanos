﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class Lista_SalidasE : System.Web.UI.Page
    {
        Salida_Negocios ejecutor = new Salida_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {
            RepeaterSalida.DataSource = ejecutor.MostrarDatos();
            RepeaterSalida.DataBind();
        }
    }
}