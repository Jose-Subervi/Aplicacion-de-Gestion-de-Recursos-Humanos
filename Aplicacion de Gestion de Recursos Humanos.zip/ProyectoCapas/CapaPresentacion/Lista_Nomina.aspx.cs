﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocio;
using CapaEntidad;

namespace CapaPresentacion
{
    public partial class Lista_Nomina : System.Web.UI.Page
    {
       
        Nomina_Negocios ejecutor = new Nomina_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {
            RepeaterNomina.DataSource = ejecutor.MostrarDatos();
            RepeaterNomina.DataBind();
        }

        protected void ButtonGuardar_Click(object sender, EventArgs e)
        {
     
        }
    }
}