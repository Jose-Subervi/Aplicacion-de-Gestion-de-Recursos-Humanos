﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocio;
using CapaEntidad;

namespace CapaPresentacion
{
    public partial class Formulario_Empleados : System.Web.UI.Page
    {
        Empleados emp = new Empleados();
        Empleados_Negocios ejecutor = new Empleados_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonGuardar_Click(object sender, EventArgs e)
        {
            emp.Codigo_Empleado = TextBoxCodigo_Empleado.Text;
            emp.Nombre = TextBoxNombre.Text;
            emp.Apellido = TextBoxApellido.Text;
            emp.Telefono = TextBoxTelefono.Text;
            emp.Departamento = TextBoxDepartamento.Text;
            emp.Cargo = TextBoxCargo.Text;
            emp.Salario = int.Parse(TextBoxSalario.Text);
            emp.Fecha_Ingreso = TextBoxFecha_Ingreso.Text;
            emp.Estatus = DropDownList2.SelectedValue;

            ejecutor.GuardarEmpleados(emp);

            TextBoxCodigo_Empleado.Text = " ";
            TextBoxNombre.Text = " ";
            TextBoxApellido.Text = " ";
            TextBoxTelefono.Text = " ";
            TextBoxDepartamento.Text = " ";
            TextBoxCargo.Text = " ";
            TextBoxSalario.Text = " ";
            TextBoxFecha_Ingreso.Text = " ";
        }
        protected void ButtonActualizar_Click(object sender, EventArgs e)
        {
            emp.ID = int.Parse(TextBoxID.Text);
            emp.Codigo_Empleado = TextBoxCodigo_Empleado.Text;
            emp.Nombre = TextBoxNombre.Text;
            emp.Apellido = TextBoxApellido.Text;
            emp.Telefono = TextBoxTelefono.Text;
            emp.Departamento = TextBoxDepartamento.Text;
            emp.Cargo = TextBoxCargo.Text;
            emp.Salario = int.Parse(TextBoxSalario.Text);
            emp.Fecha_Ingreso = TextBoxFecha_Ingreso.Text;
            emp.Estatus = DropDownList2.SelectedValue;

            ejecutor.ActualizarEmpleados(emp);

            TextBoxID.Text = " ";
            TextBoxCodigo_Empleado.Text = " ";
            TextBoxNombre.Text = " ";
            TextBoxApellido.Text = " ";
            TextBoxTelefono.Text = " ";
            TextBoxDepartamento.Text = " ";
            TextBoxCargo.Text = " ";
            TextBoxSalario.Text = " ";
            TextBoxFecha_Ingreso.Text = " ";
        }
        protected void ButtonBorrar_Click(object sender, EventArgs e)
        {
            emp.ID = int.Parse(TextBoxID.Text);

            ejecutor.BorrarEmpleados(emp);

            TextBoxID.Text = " ";

        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}