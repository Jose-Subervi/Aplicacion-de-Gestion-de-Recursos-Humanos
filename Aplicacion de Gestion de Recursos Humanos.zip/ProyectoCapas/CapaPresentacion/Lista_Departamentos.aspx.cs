﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class Lista_Departamentos : System.Web.UI.Page
    {
        Departamentos_Negocios ejecutor = new Departamentos_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {
            RepeaterDepartamento.DataSource = ejecutor.MostrarDatos();
            RepeaterDepartamento.DataBind();
        }
    }
}