﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaEntidad;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class Filtros_emp_Salida : System.Web.UI.Page
    {
        Filtros_Salidas emp = new Filtros_Salidas();
        Filtros_emp_Salida_Negocio ejecutor = new Filtros_emp_Salida_Negocio();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonGuardar_Click(object sender, EventArgs e)
        {
            emp.Fecha_Ingreso = TextBoxFiltroFechaI.Text;

            ejecutor.Filtro_EmpleadosS(emp);
            ejecutor.GuardarEmpleadosS(emp);

            RepeaterFiltroEmpleadoSalida.DataSource = ejecutor.ListarFiltrosEmpleados();
            RepeaterFiltroEmpleadoSalida.DataBind();
        }
    }
}