﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class Lista_Licencias : System.Web.UI.Page
    {
        Licencias_Negocios ejecutor = new Licencias_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {
            RepeaterLicencias.DataSource = ejecutor.MostrarDatos();
            RepeaterLicencias.DataBind();
        }
    }
}