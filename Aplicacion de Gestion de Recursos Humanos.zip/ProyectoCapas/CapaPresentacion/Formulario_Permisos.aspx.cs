﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocio;
using CapaEntidad;

namespace CapaPresentacion
{
    public partial class Formulario_Permisos : System.Web.UI.Page
    {
        Permisos pm = new Permisos();
        Permisos_Negocios ejecutor = new Permisos_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonGuardar_Click(object sender, EventArgs e)
        {
            pm.ID_Permisos = int.Parse(TextBoxID.Text);
            pm.Comentarios = TextBoxComentarios.Text;
            pm.Desde = TextBoxDesde.Text;
            pm.Hasta = TextBoxHasta.Text;

            ejecutor.AgregarEmp(pm);
            ejecutor.GuardarPermisos(pm);

            TextBoxHasta.Text = " ";
            TextBoxDesde.Text = " ";
            TextBoxComentarios.Text = " ";
            TextBoxID.Text = " ";
        }

        protected void ButtonActualizar_Click(object sender, EventArgs e)
        {
            pm.ID_Permisos = int.Parse(TextBoxID.Text);
            pm.Comentarios = TextBoxComentarios.Text;
            pm.Desde = TextBoxDesde.Text;
            pm.Hasta = TextBoxHasta.Text;

            ejecutor.ActualizarPermisos(pm);

            TextBoxHasta.Text = " ";
            TextBoxDesde.Text = " ";
            TextBoxComentarios.Text = " ";
            TextBoxID.Text = " ";
        }

        protected void ButtonBorrar_Click(object sender, EventArgs e)
        {
            pm.ID_Permisos = int.Parse(TextBoxID.Text);
            pm.Comentarios = TextBoxComentarios.Text;
            pm.Desde = TextBoxDesde.Text;
            pm.Hasta = TextBoxHasta.Text;

            ejecutor.BorrarPermisos(pm);

            TextBoxHasta.Text = " ";
            TextBoxDesde.Text = " ";
            TextBoxComentarios.Text = " ";
            TextBoxID.Text = " ";
        }
    }
}