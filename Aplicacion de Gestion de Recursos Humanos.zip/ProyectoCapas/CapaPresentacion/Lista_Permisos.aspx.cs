﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class Lista_Permisos : System.Web.UI.Page
    {
        Permisos_Negocios ejecutor = new Permisos_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {
            RepeaterPermisos.DataSource = ejecutor.MostrarDatos();
            RepeaterPermisos.DataBind();
        }
    }
}