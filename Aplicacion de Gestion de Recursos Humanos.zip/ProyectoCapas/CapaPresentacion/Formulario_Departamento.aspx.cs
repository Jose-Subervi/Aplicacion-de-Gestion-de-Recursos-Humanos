﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocio;
using CapaEntidad;

namespace CapaPresentacion
{
    public partial class Formulario_Departamento : System.Web.UI.Page
    {
        Departamentos dep = new Departamentos();
        Departamentos_Negocios ejecutor = new Departamentos_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonGuardar_Click(object sender, EventArgs e)
        {
            dep.Codigo_Departamento = TextBoxCodigo_Departamento.Text;
            dep.Nombre = TextBoxNombre.Text;


            ejecutor.GuardarDepartamento(dep);

            TextBoxCodigo_Departamento.Text = " ";
            TextBoxNombre.Text = " ";

        }

        protected void ButtonActualizar_Click(object sender, EventArgs e)
        {
            dep.ID_Departamento = int.Parse(TextBoxID.Text);
            dep.Codigo_Departamento = TextBoxCodigo_Departamento.Text;
            dep.Nombre = TextBoxNombre.Text;


            ejecutor.ActualizarDepartamento(dep);

            TextBoxID.Text = " ";
            TextBoxCodigo_Departamento.Text = " ";
            TextBoxNombre.Text = " ";

        }

        protected void ButtonBorrar_Click(object sender, EventArgs e)
        {
            dep.ID_Departamento = int.Parse(TextBoxID.Text);
            dep.Codigo_Departamento = TextBoxCodigo_Departamento.Text;
            dep.Nombre = TextBoxNombre.Text;

            ejecutor.BorrarDepartamento(dep);

            TextBoxID.Text = " ";
            TextBoxCodigo_Departamento.Text = " ";
            TextBoxNombre.Text = " ";

        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}