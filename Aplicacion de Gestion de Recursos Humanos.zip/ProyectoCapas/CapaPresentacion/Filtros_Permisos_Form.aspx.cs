﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaEntidad;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class Filtros_Permisos_Form : System.Web.UI.Page
    {
        Filtro_Permisos emp = new Filtro_Permisos();
        Filtros_Permisos_Negocios ejecutor = new Filtros_Permisos_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonGuardar_Click(object sender, EventArgs e)
        {
            emp.Empleado = TextBoxFiltroPermisos.Text;

            ejecutor.Filtro_Permisos(emp);
            ejecutor.GuardarPermisos(emp);

            RepeaterFiltroPermisos.DataSource = ejecutor.ListarFiltrosPermisos();
            RepeaterFiltroPermisos.DataBind();
        }
    }
}