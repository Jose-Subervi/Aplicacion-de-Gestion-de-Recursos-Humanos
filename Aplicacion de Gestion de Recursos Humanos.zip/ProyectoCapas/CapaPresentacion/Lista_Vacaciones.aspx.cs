﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class Lista_Vacaciones : System.Web.UI.Page
    {
        Vacacione_Negocios ejecutor = new Vacacione_Negocios();
        protected void Page_Load(object sender, EventArgs e)
        {
            RepeaterVacaciones.DataSource = ejecutor.MostrarDatos();
            RepeaterVacaciones.DataBind();
        }
    }
}